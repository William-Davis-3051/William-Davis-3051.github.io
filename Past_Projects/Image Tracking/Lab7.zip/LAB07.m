display(['Image Processing'])
clear; 
load im30;
figure(2); 
clf; 
imshow(im30);
hold on; 
axis on;
[c r] = imfindcircles(im30,[13 100],'sensitivity',.91,'EdgeThreshold',.1); 
viscircles(c,r);
[x y]=ginput(4);
distance=zeros(4);
 x(5) = x(1);
 y(5) = y(1);
for i = 1:4
    for j = 1:4
        distance(i,j) = sqrt((x(i)-x(j))^2+(y(i)-y(j))^2);
    end 
end
disp(distance);
v=VideoReader('wiffleBalls.mov');
[c r] = imfindcircles(im30,[13 100],'sensitivity',.91,'EdgeThreshold',.1);
pc = c;
count = 0;
displment = zeros(47,1);
k = 1;
while hasFrame(v)==true
    im = readFrame(v);
    figure(3);
    imshow(im);
    hold on; 
    axis on;
    [c r] = imfindcircles(im,[25 70],'sensitivity',.92,'EdgeThreshold',.066);
    cc = c;
    viscircles(c,r);
    for i = 1:size(pc,1)
        for j = 1:size(c,1)
            dist(i,j) = sqrt((cc(j,1)-pc(i,1))^2+(cc(j,2)-pc(i,2))^2);
        end 
    end
    pc = cc;
    d = zeros(size(c,1),1);
    for i= 1:size(dist,1)
        d(i) = min(dist(i,:));
    end
    displment(k) = max(d);
    
    velocity = displment*v.framerate*.005;
    disp(velocity(k));disp('ft/sec');
    k = k+1;

end
figure(4);
displment(1,1) = 0;
velocity (1,1) = 0;
p = k/v.framerate;
t= linspace(1,p,k);
plot (velocity);


%Notes 
%[c r] = imfindcircles(im30,[10 100])
    %storing x coords. in c and y coords. in r (done in pixels). 
    %[10 100] is the min and max radius. The estimated radii, in pixels, for he circles are 
    %returned in the column vector RADII (r=radii, c=center  

% 'Sensitivity '  - Specifies the sensitivity factor in the range [0 1]
%                       for finding circles. A high sensitivity value leads
%                       to detecting more circles, including weak or
%                       partially obscured ones, at the risk of a higher
%                       false detection rate. Default value: 0.85
%  
%  'EdgeThreshold' - A scalar K in the range [0 1], specifying the gradient 
%                    threshold for determining edge pixels. K = 0 sets the
%                    threshold at zero-gradient magnitude, and K = 1 sets
%                    the threshold at the maximum gradient magnitude in
%                    the image. A high EdgeThreshold value leads to
%                    detecting only those circles that have relatively
%                    strong edges. A low EdgeThreshold value will, in
%                    addition, lead to detecting circles with relatively
%                    faint edges. By default, imfindcircles chooses the
%                    value automatically using the function GRAYTHRESH.

%ginput Graphical input from mouse.
%     [X,Y] = ginput(N) gets N points from the current axes and returns
%     the X- and Y-coordinates in length N vectors X and Y.  The cursor
%     can be positioned using a mouse.  Data points are entered by pressing
%     a mouse button or any key on the keyboard except carriage return,
%     which terminates the input before N points are entered.